RenPyVN Studio 2.4.0 - Smart Translation QA (GitHub delta patch)
Only for 2.3.6 ThirdPersonQAFix.
1. Close RenPyVN Studio.
2. Extract ZIP; place whole REN240_GITHUB_PATCH folder in the folder containing RenPyVN_Studio.exe.
3. Run UPDATE_236_TO_240.bat inside patch folder.
4. Confirm CAP NHAT THANH CONG then restart RenPyVN Studio.
This is the equivalent code upgrade to 2.4.0, stored as strict verified diffs to reduce download size.
It does not modify project databases, rules or Ren'Py scripts.
Experimental QA feature: not yet validated on Windows GUI or real provider.
