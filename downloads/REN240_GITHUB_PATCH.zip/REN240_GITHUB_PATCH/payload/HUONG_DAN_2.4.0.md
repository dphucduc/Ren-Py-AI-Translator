# RenPyVN Studio 2.4.0 – Smart Translation QA (thử nghiệm)

Bản này xây trên mã nguồn 2.3.6. Không thay đổi JSON AI ngoài hay kết luận người nói/nghe.

## Mục 02 Kết nối AI
- AI kiểm duyệt độc lập sau mỗi bản dịch: bật/tắt; mặc định bật. Tốn thêm API/token.
- Tự sửa có kiểm chứng: mặc định bật; sửa tối đa 2 lần/câu (0–3 tùy chọn), không phụ thuộc mức retry dịch 0 = vô hạn.
- Review chỉ kiểm định source, target, context, locked_pair, SELF; không tự sửa hồ sơ, người nghe, rules.
- Nếu AI QA gặp HTTP 429, tạm dừng các lời gọi QA tiếp theo trong phiên; rà toàn dự án dừng ở batch đó. Khi kiểm duyệt thiếu ID, lỗi API/JSON hoặc không chắc: GIỮ bản dịch để người dùng duyệt, không coi là PASS và không lặp vô hạn.
- AI sửa phải qua lại local QA (token, glossary, lock, SELF) và AI review lần nữa trước khi thay bản cũ.
- Bản gốc và bản đã sửa lưu tại .renpyvn/smart_qa_history.jsonl.
- Sửa vẫn có thể sai; phải kiểm lại bằng game và tự duyệt trước khi xuất.

## Mục 04
- Nút AI rà & tự sửa bản dịch: rà cả các câu đã PASS/đã duyệt; hỏi xác nhận vì tốn quota.
- Câu đã duyệt và PASS không đổi. Câu sửa xong chuyển Cần duyệt; câu sai chưa sửa được cũng Cần duyệt. Câu lỗi cấu trúc không thể xuất.
- Nút Rà xưng hô bản dịch cũ vẫn là kiểm tra cục bộ và không tốn API.

## Lưu ý
- Không thể xác minh trên Windows/API model thật trong môi trường này. Đã có kiểm thử tự động mock provider và đối chiếu câu 965.
- Giải nén đầy đủ rồi chạy RenPyVN_Studio.exe hoặc RUN_TRANSLATOR.bat.
- Dừng & lưu trước khi nâng cấp; luôn sao lưu .renpyvn và script gốc trước khi thử trên project chính.
