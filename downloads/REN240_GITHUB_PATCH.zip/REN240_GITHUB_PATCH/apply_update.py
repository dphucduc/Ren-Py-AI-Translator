from pathlib import Path
import sys,re,hashlib,json,shutil,os,time
here=Path(__file__).resolve().parent
root=next((p for p in (here.parent,here) if (p/'RenPyVN_Studio.exe').is_file() and (p/'renpyvn/__init__.py').is_file()),None)
if root is None:raise SystemExit('Khong tim thay RenPyVN_Studio.exe; dat ca folder REN240_GITHUB_PATCH trong thu muc app 2.3.6.')
manifest=json.loads((here/'manifest.json').read_text(encoding='utf8'))
def digest(b):return hashlib.sha256(b).hexdigest()
def patch(src,diff):
    original=src.splitlines(keepends=True);d=diff.splitlines(keepends=True);out=[];j=0;i=2
    if not (d[0].startswith('--- ') and d[1].startswith('+++ ')):raise ValueError('diff header')
    while i<len(d):
        m=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',d[i])
        if not m:raise ValueError('diff hunk: '+d[i][:80])
        old_start=int(m.group(1));old_count=int(m.group(2) or 1);new_count=int(m.group(4) or 1);i+=1
        if old_start-1<j:raise ValueError('overlapping diff')
        out.extend(original[j:old_start-1]);j=old_start-1;oc=nc=0
        while i<len(d) and not d[i].startswith('@@ '):
            line=d[i];i+=1
            if not line or line[0] not in ' +-':raise ValueError('invalid diff line')
            if line[0]==' ':
                if j>=len(original) or original[j]!=line[1:]:raise ValueError('context mismatch')
                out.append(original[j]);j+=1;oc+=1;nc+=1
            elif line[0]=='-':
                if j>=len(original) or original[j]!=line[1:]:raise ValueError('remove mismatch')
                j+=1;oc+=1
            else:out.append(line[1:]);nc+=1
        if oc!=old_count or nc!=new_count:raise ValueError('hunk line count mismatch')
    out.extend(original[j:]);return ''.join(out)
changes={}
for rel,check in manifest.items():
    dst=root/rel
    if 'old' in check:
        if not dst.is_file():raise SystemExit('Thieu '+rel)
        raw=dst.read_bytes()
        if digest(raw)==check['new']:
            continue
        if digest(raw)!=check['old']:raise SystemExit('Khong phai dung ban 2.3.6 goc, da dung an toan tai '+rel)
        diff=(here/'payload'/(Path(rel).name+'.diff')).read_text(encoding='utf8')
        raw=patch(raw.decode('utf8'),diff).encode('utf8')
    else:raw=(here/'payload'/rel).read_bytes()
    if digest(raw)!=check['new']:raise SystemExit('Hash mismatch '+rel)
    changes[rel]=raw
if not changes:
 print('Da cap nhat 2.4.0 truoc do.');raise SystemExit(0)
backup=root/('BACKUP_BEFORE_240_'+time.strftime('%Y%m%d-%H%M%S'))
for rel in changes:
    dst=root/rel
    if dst.is_file():
        bak=backup/rel;bak.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(dst,bak)
for rel,raw in changes.items():
    dst=root/rel;dst.parent.mkdir(parents=True,exist_ok=True)
    tmp=dst.with_name(dst.name+'.240.tmp');tmp.write_bytes(raw);os.replace(tmp,dst)
print('CAP NHAT THANH CONG: RenPyVN 2.4.0; da luu backup code tai',backup)
print('KHONG sua rules.json, progress.sqlite3, hay script game.')
