@echo off
cd /d "%~dp0"
set "PYEXE=%~dp0..\runtime\python.exe"
if not exist "%PYEXE%" (
 echo Khong tim thay runtime\python.exe trong thu muc RenPyVN 2.3.6.
 pause
 exit /b 1
)
"%PYEXE%" -E -s "%~dp0apply_update.py"
if errorlevel 1 echo Cap nhat khong thanh cong. Doc thong bao phia tren.
pause
