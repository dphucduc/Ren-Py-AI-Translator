"""Build a binary-only RenPyVN Windows release from a private 2.4.2 source folder.
Run on Windows x64 with the bundled Python 3.12 (see README_RELEASE.md).
It does not push source or binaries to a public repository.
"""
from __future__ import annotations

import argparse
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import zipfile

VERSION = "2.4.2"
PUBLIC_NAME = f"RenPyVN_Studio_v{VERSION}_Windows_x64_BINARY_ONLY"
GUARD = '    if not (app_home()/"vendor"/"unrpyc"/"unrpyc.py").exists():\n'
FROZEN = 'if getattr(sys,"frozen",False): cmd=[sys.executable,"--decompile",str(staged)]'
REPLACEMENT = 'if getattr(sys,"frozen",False) or "__compiled__" in globals(): cmd=[sys.executable,"--decompile",str(staged)]'


def prepare(root: Path, stage: Path) -> None:
    required = [root / "app.py", root / "renpyvn" / "gui.py", root / "renpyvn" / "archives.py",
                root / "vendor" / "unrpyc" / "unrpyc.py", root / "LICENSE",
                root / "THIRD_PARTY_NOTICES.md"]
    missing = [str(p) for p in required if not p.is_file()]
    if missing:
        raise RuntimeError("Not a complete RenPyVN source folder: " + ", ".join(missing))
    version_text = (root / "renpyvn" / "__init__.py").read_text("utf-8")
    if '2.4.2-PairSearch' not in version_text:
        raise RuntimeError("This build kit is for the unmodified RenPyVN Studio 2.4.2 source.")
    if stage.exists():
        shutil.rmtree(stage)
    stage.mkdir(parents=True)
    shutil.copy2(root / "app.py", stage / "app.py")
    shutil.copytree(root / "renpyvn", stage / "renpyvn",
                    ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.pyo"))
    shutil.copytree(root / "vendor" / "unrpyc", stage / "vendor" / "unrpyc",
                    ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.pyo", ".git"))
    archives = stage / "renpyvn" / "archives.py"
    text = archives.read_text("utf-8")
    lines = text.splitlines(keepends=True)
    found = False
    result = []
    i = 0
    while i < len(lines):
        if lines[i] == GUARD:
            if i + 1 >= len(lines) or 'raise ArchiveError("Thiếu vendor/unrpyc.' not in lines[i + 1]:
                raise RuntimeError("Unexpected vendor preflight: refusing unsafe source modification")
            found = True
            i += 2
        else:
            result.append(lines[i])
            i += 1
    text = "".join(result)
    if not found or text.count(FROZEN) != 1:
        raise RuntimeError("Unexpected decompile worker: refusing unsafe source modification")
    # Nuitka sets __compiled__, not sys.frozen. Preserve the existing subprocess boundary.
    text = text.replace(FROZEN, REPLACEMENT)
    archives.write_text(text, encoding="utf-8")
    # Validate all private modules before the C compilation starts.
    for item in (stage / "renpyvn").glob("*.py"):
        compile(item.read_bytes(), str(item), "exec")
    compile((stage / "app.py").read_bytes(), str(stage / "app.py"), "exec")
    print("Prepared source-only build stage. No user project or API settings copied.")


def build(root: Path, work: Path, output: Path, python_exe: Path) -> Path:
    stage = work / "stage"
    prepare(root, stage)
    if os.name != "nt":
        raise RuntimeError("A Windows x64 binary must be compiled on Windows. Stage validation passed.")
    if not python_exe.is_file():
        raise RuntimeError(f"Missing build Python: {python_exe}")
    subprocess.run([str(python_exe), "-m", "pip", "install", "--upgrade",
                    "nuitka", "ordered-set", "zstandard"], check=True)
    env = dict(os.environ)
    env["PYTHONPATH"] = os.pathsep.join([str(stage), str(stage / "vendor" / "unrpyc"),
                                         env.get("PYTHONPATH", "")])
    compilation = work / "compile"
    compilation.mkdir(parents=True, exist_ok=True)
    cmd = [str(python_exe), "-m", "nuitka", "--mode=standalone", "--mingw64",
           "--assume-yes-for-downloads", "--enable-plugin=tk-inter",
           "--windows-console-mode=disable", "--include-package=renpyvn",
           "--include-module=unrpyc", "--include-package=decompiler",
           "--output-filename=RenPyVN_Studio.exe", f"--output-dir={compilation}",
           str(stage / "app.py")]
    print("Compiling native Windows build with Nuitka; first build may take a while.")
    subprocess.run(cmd, env=env, cwd=stage, check=True)
    dist = compilation / "app.dist"
    if not (dist / "RenPyVN_Studio.exe").is_file():
        raise RuntimeError("Nuitka did not produce the expected .exe")
    shutil.copy2(root / "LICENSE", dist / "LICENSE")
    shutil.copy2(root / "THIRD_PARTY_NOTICES.md", dist / "THIRD_PARTY_NOTICES.md")
    (dist / "vendor" / "unrpyc").mkdir(parents=True, exist_ok=True)
    shutil.copy2(root / "vendor" / "unrpyc" / "LICENSE", dist / "vendor" / "unrpyc" / "LICENSE")
    (dist / "README_DOWNLOAD.txt").write_text(
        "RenPyVN Studio 2.4.2 Windows x64\n\n"
        "Extract ALL files, run RenPyVN_Studio.exe.\n"
        "Bring your own API keys or Ollama. No game scripts or private accounts included.\n"
        "The software is MIT licensed; see LICENSE and THIRD_PARTY_NOTICES.md.\n"
        "Executable builds can still be reverse engineered; source files are not distributed.\n",
        encoding="utf-8")
    unwanted = [p for p in dist.rglob("*") if p.is_file() and
                p.suffix.lower() in {".py", ".pyc", ".pyo", ".rpy", ".rpyc", ".sqlite3"}]
    if unwanted:
        raise RuntimeError("REFUSING TO PUBLISH source / game / database files: " +
                           ", ".join(str(p.relative_to(dist)) for p in unwanted[:12]))
    output.mkdir(parents=True, exist_ok=True)
    archive = output / f"{PUBLIC_NAME}.zip"
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=6, allowZip64=True) as z:
        for item in sorted(dist.rglob("*")):
            if item.is_file():
                z.write(item, f"{PUBLIC_NAME}/{item.relative_to(dist).as_posix()}")
    with zipfile.ZipFile(archive) as z:
        if z.testzip():
            raise RuntimeError("Broken release ZIP")
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    (output / "SHA256SUMS.txt").write_text(f"{digest}  {archive.name}\n", encoding="ascii")
    print("Built:", archive)
    print("SHA-256:", digest)
    print("No plain source, project database, or game scripts included.")
    print("NEXT: Smoke-test RenPyVN_Studio.exe on Windows, then attach the ZIP to a PUBLIC downloads-only GitHub Release.")
    return archive


def main() -> int:
    p = argparse.ArgumentParser(description="Private Windows build; public binary-only ZIP")
    p.add_argument("--source", type=Path, default=Path(__file__).resolve().parent)
    p.add_argument("--output", type=Path, default=None)
    p.add_argument("--prepare-only", action="store_true", help="Validate source/patch; no native build")
    a = p.parse_args()
    root = a.source.resolve()
    work = root / "_release_build_242"
    work.mkdir(parents=True, exist_ok=True)
    if a.prepare_only:
        prepare(root, work / "stage")
        print("Preparation OK; no release binary has been built.")
        return 0
    archive = build(root, work, (a.output or root / "_release_binary_only").resolve(),
                    root / "runtime" / "python.exe")
    return 0 if archive.is_file() else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print("BUILD FAILED:", exc, file=sys.stderr)
        raise SystemExit(1)
