# RenPyVN Studio 2.4.2 — binary-only release kit

**Purpose:** Make a public Windows x64 download without making the development repo public or uploading readable `renpyvn/*.py` source.

### Build on your Windows PC

1. Extract the *full* v2.4.2 application/source ZIP privately (not in a public repository). Ensure its root contains `app.py`, `renpyvn/`, `vendor/unrpyc/`, `runtime/python.exe`, and `RenPyVN_Studio.exe`.
2. Place both `BUILD_BINARY_ONLY.py` and `BUILD_BINARY_ONLY.cmd` into that same root.
3. Run `BUILD_BINARY_ONLY.cmd`, with internet access for the first Nuitka/compiler setup. It uses your bundled Python 3.12 and can take a while.
4. When it says **Built**, use `_release_binary_only/RenPyVN_Studio_v2.4.2_Windows_x64_BINARY_ONLY.zip` as the intended release asset. SHA256SUMS.txt is next to it.
5. Test on Windows *before publishing*: launch exe, open demo/new project, import Rule JSON, check pronoun alerts, tab 03 pair search, and optional unrpyc conversion. Stop if anything fails.

This compiles proprietary RenPyVN modules with Nuitka. It only copies MIT license notices into the public distributable, not source modules or personal projects. `.py`/`.pyc`/`.rpy`/`.sqlite3` in the output cause the build to fail. It never uploads your private source. Native executables can still be reverse engineered; this is distribution without plain source, not absolute DRM.

### Publication

Keep `dphucduc/Ren-Py-AI-Translator` **Private**. Create a separate **Public** repo such as `RenPyVN-Downloads` containing only README and releases. The free GitHub-generated `Source code (zip/tar.gz)` links then contain only that public repo's README, not your private app source. Upload the validated binary ZIP as a release asset under tag `v2.4.2` and describe it as Windows x64. The current ChatGPT GitHub integration cannot create a repository, change visibility, or upload binary release assets, so those UI steps require your account.

Do **not** publish the old `RenPyVN_Studio_v2.4.2_Windows_x64_PUBLIC.zip`: it includes readable `app.py` and `renpyvn/*.py` files.
