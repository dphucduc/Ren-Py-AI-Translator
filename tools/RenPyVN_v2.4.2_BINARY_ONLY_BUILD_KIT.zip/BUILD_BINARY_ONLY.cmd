@echo off
setlocal
set "APP=%~dp0"
if not exist "%APP%runtime\python.exe" (
  echo STOP: Copy BUILD_BINARY_ONLY.py and BUILD_BINARY_ONLY.cmd beside app.py in the FULL v2.4.2 folder.
  pause
  exit /b 1
)
"%APP%runtime\python.exe" "%APP%BUILD_BINARY_ONLY.py" --source "%APP%"
set "RESULT=%ERRORLEVEL%"
if not "%RESULT%"=="0" echo BUILD FAILED; no public release was uploaded.
pause
exit /b %RESULT%
